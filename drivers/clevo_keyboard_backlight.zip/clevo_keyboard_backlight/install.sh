#!/bin/bash
#
# From https://forums.linuxmint.com/viewtopic.php?t=287190

cd module/

make clean
make
sudo insmod clevo-xsm-wmi.ko #load the module into the kernel

# Making the install persistent after reboots
sudo make install

# If you get an ssl error with the previous command, run :
sudo install -m644 clevo-xsm-wmi.ko /lib/modules/$(uname -r)/extra

sudo depmod

sudo tee /etc/modprobe.d/clevo-xsm-wmi.conf <<< 'options clevo-xsm-wmi kb_color=cyan,cyan,cyan,cyan kb_brightness=9'

sudo mkinitcpio -P
